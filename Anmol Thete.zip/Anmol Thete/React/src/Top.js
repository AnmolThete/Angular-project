import React ,{ useState } from "react";


export default function Top(props){
    let [sCountry, setsCountry] = useState('');
    return (
        <div>
        <form className="text-center m-5">
            <input type="text" value={sCountry} placeholder="country name" onChange={(e)=> setsCountry(e.target.value)}/>
            
        </form>
        <table className="table table-sm">
            <thead>
                <tr>
                <th>Sr. No.</th>
            <th>Country</th>
            <th>Total Confirmed</th>
            <th>Total Recovered</th>
            <th>Total Deaths</th>
            <th>Total Active Cases</th>
                </tr>
            </thead>
            <tbody>
                {props.data.filter((val)=>{
                    if(sCountry === " "){
                        return 0
                    }
                    else if(val.Country.toLowerCase().includes(sCountry.toLowerCase())){
                        return val
                    }
                }).slice(0,1).map((c, index) => (
                    <tr key={index + 1}>
                      <td>{index + 1}</td>
                
                      
                          <td>{c.Country}</td>
                          <td>{c.TotalConfirmed}</td>
                          <td>{c.TotalRecovered}</td>
                          <td>{c.TotalDeaths}</td>
                          <td>
                            {c.TotalConfirmed -
                              (c.TotalRecovered + c.TotalDeaths)}
                          </td>
                        </tr>
                      ))}
            </tbody>

        </table>
        </div>
    )
}