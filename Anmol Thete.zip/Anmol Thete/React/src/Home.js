
import CovidTracker from "./CovidTracker";

const Home=()=>(
    <div className="Home">
        <h1 className="text-center">
            Home
        </h1>
        <p className="text-center">       
            <CovidTracker/>
        </p>
 

    </div>
)

export default Home