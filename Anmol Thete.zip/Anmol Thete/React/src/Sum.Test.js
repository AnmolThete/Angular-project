import {Sum } from './Sum';
it('T1', () => {
    const Sum = add(4, 5);
    expect(Sum).toEqual(9);
  })
  it('T2',()=>{
      const Sum = add(3,2);
      expect(Sum).toEqual(5);
  })
  ;