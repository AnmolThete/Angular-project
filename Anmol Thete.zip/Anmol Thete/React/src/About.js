const About=()=>(
    <div className="About">
        <h1>
            About
            Covid website
        </h1>

    </div>
)

export default About