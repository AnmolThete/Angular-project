import React, { useState } from "react";

import Form from "./Form";
export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  

  function validateForm() {
    return email.length > 0 && password.length > 0 && password === "admin";
  }

  function handleSubmit(event) {
      
    event.preventDefault();
    
  }

  return (
      <div className="card">
    <div className=" card-body col d-flex justify-content-center">
      <form onSubmit={handleSubmit}>
        <div className="form-group" size="lg" controlId="email">
          <label>Email</label>
          <input
            autoFocus
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <br/>
        <div className="form-group" size="lg" controlId="password">
          <label>Password</label>
          <input className="form-group"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <br/>
        <button block size="lg" type="submit" disabled={!validateForm()} >
          Login
        </button>
      </form>
    </div>
    </div>
  );
}