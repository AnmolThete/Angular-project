import React, { Component } from "react";

import {BrowserRouter, Link} from 'react-router-dom';
class NavBar extends Component {
  render() {
    return (
      <div >  
        <nav className="navbar navbar-dark bg-dark mb-3">
          <a className="navbar">
          <Link to="/">  Home</Link></a>
          <a className="nav-item"><Link to="/About">  About</Link></a>
          <a className="nav-item"><Link to="/login">  Login</Link></a>
          <a className="nav-item"><Link to="/form">  Form</Link></a>
          <a className="nav-item"><Link to="/graph">  Graph</Link></a>     
        </nav>
      </div>
    );
  }
}

export default NavBar;

