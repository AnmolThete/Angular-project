import createaccount
import transaction
from sqlconnection import mydb,cursor
def customer():
    while (1):
        print('''
                1. Create Account
                2. Deposit Amount
                3. Withdraw Amount
                4. Tansfer Amount
                5. Balance Enquiry
                6. Delete/Close Account
                7. Exit Menus
                ''')

        choice = int(input(" Choose option "))
        if (choice == 1):
            createaccount.b.OpenAccount()

        elif (choice == 2):
            transaction.t.depositAmount()

        elif (choice == 3):
            transaction.t.withdrawlAmount()

        elif(choice == 4):
            transaction.t.transferAmount()

        elif (choice == 5):
            transaction.t.balanceEnq()

        elif (choice == 6):
            createaccount.b.closeAccount()

        elif (choice == 7):
            print("Thank you ")
            if mydb.is_connected():
                cursor.close()
                mydb.close()
                print("My sql connection closed")
            exit()


        else:
            print("Enter valid choice")
            customer()