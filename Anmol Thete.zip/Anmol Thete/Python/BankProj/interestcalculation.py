from  sqlconnection import cursor,mydb
import datetime as dt
d = dt.datetime.today()

def interestCalculation():
    accNo = int(input("Enter Account no for which interest to be calculated = "))
    query = ("select Accountnumber from Account where Accountnumber > 0")
    cursor.execute(query)
    temp = cursor.fetchall()
    data_accNo = [i[0] for i in temp]
    if(d.day == 30):
        if accNo in data_accNo:
            query = (f"select OpeningBalance from Account where Accountnumber = {accNo}")
            cursor.execute(query)
            accBal = cursor.fetchall()[0][0]
            accBal += accBal*0.1
            print(f"Interested calculated for given month for this account is {accBal*0.1}")
            cont = input("Enter Y/y to add this in customer's account")
            if cont == "Y":
                print(f"Thanks for using our service. Your updated balance = {accBal}")
                query = (f"update Account set OpeningBalance = {accBal} where Accountnumber = {accNo}")
                cursor.execute(query)
                mydb.commit()
                query = (f"select Name from Account where Accountnumber = {accNo}")
                cursor.execute(query)
                name = cursor.fetchall()[0][0]
                query = (f"insert into amount (Name, Accountnumber, Balance, type , dot) "
                        f"values ('{name}', {accNo}, {accBal*0.1} , 'Interest' , '{dt.datetime.today()}')")
                cursor.execute(query)
                mydb.commit()
        else:
            print("No Record Found in Our Database. Please Try Again...!")

    else:
        print("Interst can only be calculated on 30th of the month")


