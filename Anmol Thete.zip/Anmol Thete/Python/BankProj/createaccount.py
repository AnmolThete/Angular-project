from sqlconnection import cursor,mydb
import datetime as dt
from random import randint
class Bank:
    def generateAccountnumber(self,n):
        range_start = 10 ** (n - 1)
        range_end = (10 ** n) - 1
        return randint(range_start, range_end)

    def OpenAccount(self):
        print("Fill following details to create Account")
        name = input("enter your name : ")
        Accountnumber = self.generateAccountnumber(10)
        y, m, d = input("Enter your dob (yyyy-mm-dd)= ").split("-")
        dob = dt.date(int(y), int(m), int(d))
        Address = input("Enter your address : ")
        contactno = int(input("Enter your mobile no = "))
        OpeningBalance = int(input("Deposit your initial amount (>500 for saving and >1000 for term) = "))
        accountType = input("Enter type of account you wish to create (Saving/Term) : ")
        pin = int(input("Please select any 4 digit numeric pin for your account = "))
        if((accountType=="Saving" and OpeningBalance >= 500) or (accountType=="Term" and OpeningBalance >=1000)):
            query = (
                f"insert into Account (Name, Accountnumber, DOB, Address, contactno , OpeningBalance, pin, accountType) "
                f"values ('{name}', {Accountnumber}, '{dob}', '{Address}', {contactno}, {OpeningBalance}, {pin} , '{accountType}');")
            cursor.execute(query)
            mydb.commit()
            query = (f"select Accountnumber from Account where Name = '{name}'")
            cursor.execute(query)
            accno = cursor.fetchall()
            print("Conguragtulations...!! Your account is successfully created.")
            print(
                f"Your account number is {accno[0][0]}. Please remember this as it is very important you will require it"
                f" while doing any transaction.")
        else:
            print("PLease deposit minimum cash specified")


    def closeAccount(self):
        accNo = int(input("Enter your Account no = "))
        query = ("select Accountnumber from Account where Accountnumber > 0")
        cursor.execute(query)
        temp = cursor.fetchall()
        data_accNo = [i[0] for i in temp]
        counter = 0
        trails = 2
        if accNo in data_accNo:
            pin = int(input("Enter your pin no = "))
            query = (f"select Pin from Account where Accountnumber = {accNo}")
            cursor.execute(query)
            data_pin = cursor.fetchall()[0][0]
            while counter != 3:
                if data_pin == pin:
                    query = (f"select OpeningBalance from Account where Accountnumber = {accNo}")
                    cursor.execute(query)
                    accBal = cursor.fetchall()[0][0]
                    print(f"Balance in your account = {accBal} , withdraw or continue")
                    option = input("Confirm if want to close account by pressing Y : ")
                    if(option== "Y " or option=="y"):
                        query = (f"DELETE FROM Account WHERE Accountnumber = {accNo};")
                        cursor.execute(query)
                        mydb.commit()
                        print(f"Account number: {accNo} deleted successfully")
                    else:
                        print("invalid input provided")
                        break
                    break
                else:
                    print("Incorrect Pin. Please Try again.")
                if trails > 0:
                    print(f"You got {trails} more incorrect trials left.")
                    trails -= 1
                    counter += 1
                if counter == 3:
                    print("Incorrect pin trials over please start over.")
                    break
                    pin = int(input("Enter your pin no = "))
                    continue
        else:
                print("No Record Found in Our Database. Please Try Again...!")


b = Bank()



