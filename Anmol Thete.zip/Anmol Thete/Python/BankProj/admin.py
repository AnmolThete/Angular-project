import createaccount
from allaccounts import allAccounts, totalAmount
from report import displayReport
import interestcalculation
from sqlconnection import cursor,mydb
def admins():
    print("Welcome please enter password ")
    password = input()
    if(password=="admin" or password=="Admin"):
        while(1):
            print('''Login in choose options 
                    1.Display Report of particular users
                    2.Interest Calculation
                    3.Delete/Close Account
                    4.See Existing Customers
                    5.Total Amount in Bank
                    6.Exit''')

            choice = int(input("Enter your choice : "))
            if (choice == 1):
                displayReport()
            elif (choice == 2):
                interestcalculation.interestCalculation()
            elif(choice == 3):
                createaccount.b.closeAccount()
            elif(choice == 4):
                allAccounts()
            elif(choice == 5):
                totalAmount()
            elif(choice == 6):
                print("Thank you")
                if mydb.is_connected():
                    cursor.close()
                    mydb.close()
                    print("My sql connection closed")
                exit()


            else:
                print("invalid input")


    else:
        print("Incorrect password !!!")
        admins()