import mysql.connector
from mysql.connector import Error, connection, cursor
mydb = mysql.connector.connect(host="localhost", database="bank", user="root", password="admin")
print(mydb)
try:
    if(mydb.is_connected()):
        db_info=mydb.get_server_info()
        print("connected to mysql", db_info)
        cursor = mydb.cursor()
except Error as e:
    print("error while connecting to mysql")

"""finally:
    
"""