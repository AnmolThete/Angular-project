from sqlconnection import cursor,mydb
def displayReport():
    accNo = int(input("Enter your Account no = "))
    query = ("select Accountnumber from amount where Accountnumber > 0")
    cursor.execute(query)
    temp = cursor.fetchall()
    data_accNo = [i[0] for i in temp]
    counter = 0
    trails = 2
    if accNo in data_accNo:
        pin = int(input("Enter your pin no = "))
        query = (f"select Pin from Account where Accountnumber = {accNo}")
        cursor.execute(query)
        data_pin = cursor.fetchall()[0][0]
        while counter != 3:
            if data_pin == pin:
                query = (f"select Balance, Type, dot from amount where Accountnumber = {accNo}")
                cursor.execute(query)
                report = cursor.fetchall()
                print(f"Your Account statement is:  {report}")
                break

            else:
                print("Incorrect Pin. Please Try again.")
                if trails > 0:
                    print(f"You got {trails} more incorrect trials left.")
                    trails -= 1
                    counter += 1
                if counter == 3:
                    print("Incorrect pin trials over please start over.")
                    break
                pin = int(input("Enter your pin no = "))
                continue


    else:
        print("No Record Found in Our Database. Please Try Again...!")

