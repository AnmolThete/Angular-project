from sqlconnection import cursor,mydb
def allAccounts():
    query = ("select Name from Account")
    cursor.execute(query)
    temp = cursor.fetchall()
    data_accName = [ i for i in temp]
    print(data_accName)

def totalAmount():
    query = ("SELECT SUM(OpeningBalance) FROM Account")
    cursor.execute(query)
    temp = cursor.fetchone()
    print(f"Total Amount in the bank is : {temp}")


