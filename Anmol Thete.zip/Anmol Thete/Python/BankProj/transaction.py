from sqlconnection import cursor, mydb
import datetime as dt
class Transaction:
    def withdrawlAmount(self):
        accNo = int(input("Enter your Account no = "))
        query = ("select Accountnumber from Account where Accountnumber > 0")
        cursor.execute(query)
        temp = cursor.fetchall()
        data_accNo = [i[0] for i in temp]
        counter = 0
        trails = 2
        if accNo in data_accNo:
            pin = int(input("Enter your pin no = "))
            query = (f"select Pin from Account where Accountnumber = {accNo}")
            cursor.execute(query)
            data_pin = cursor.fetchall()[0][0]
            while counter != 3:
                if data_pin == pin:
                    withBal = int(input("Enter amount to withdraw = "))
                    query = (f"select OpeningBalance from Account where Accountnumber = {accNo}")
                    cursor.execute(query)
                    accBal = cursor.fetchall()[0][0]
                    minBal = accBal - withBal
                    if withBal > minBal:
                        print("You Have insufficient Balance in your account please try again...")
                    else:
                        accBal -= withBal
                        print(f"Thanks for using our service. Remaining funds in your account = {accBal}")
                        query = (f"update Account set OpeningBalance = {accBal} where Accountnumber = {accNo}")
                        cursor.execute(query)
                        mydb.commit()
                        query = (f"select Name from Account where Accountnumber = {accNo}")
                        cursor.execute(query)
                        name = cursor.fetchall()[0][0]
                        query = (f"insert into amount (Name, Accountnumber, Balance, type, dot) "
                                 f"values ('{name}', {accNo}, {withBal} , 'Debited','{dt.datetime.today()}')")
                        cursor.execute(query)
                        mydb.commit()
                    break
                else:
                    print("Incorrect Pin. Please Try again.")
                    if trails > 0:
                        print(f"You got {trails} more incorrect trials left.")
                    trails -= 1
                    counter += 1
                    if counter == 3:
                        print("Incorrect pin trials over please start over.")
                        break
                    pin = int(input("Enter your pin no = "))
                    continue
        else:
            print("No Record Found in Our Database. Please Try Again...!")

    def depositAmount(self):
        accNo = int(input("Enter your Account no = "))
        query = ("select Accountnumber from Account where Accountnumber > 0")
        cursor.execute(query)
        temp = cursor.fetchall()
        data_accNo = [i[0] for i in temp]
        counter = 0
        trails = 2
        if accNo in data_accNo:
            pin = int(input("Enter your pin no = "))
            query = (f"select Pin from Account where Accountnumber = {accNo}")
            cursor.execute(query)
            data_pin = cursor.fetchall()[0][0]
            while counter != 3:
                if data_pin == pin:
                    depBal = int(input("Enter amount to deposit = "))
                    query = (f"select OpeningBalance from Account where Accountnumber = {accNo}")
                    cursor.execute(query)
                    accBal = cursor.fetchall()[0][0]
                    accBal += depBal
                    print(f"Thanks for using our service. Your updated balance = {accBal}")
                    query = (f"update Account set OpeningBalance = {accBal} where Accountnumber = {accNo}")
                    cursor.execute(query)
                    mydb.commit()
                    query = (f"select Name from Account where Accountnumber = {accNo}")
                    cursor.execute(query)
                    name = cursor.fetchall()[0][0]
                    query = (f"insert into amount (Name, Accountnumber, Balance, type , dot) "
                            f"values ('{name}', {accNo}, {depBal} , 'Credited' , '{dt.datetime.today()}')")
                    cursor.execute(query)
                    mydb.commit()
                    break
                else:
                    print("Incorrect Pin. Please Try again.")
                    if trails > 0:
                        print(f"You got {trails} more incorrect trials left.")
                    trails -= 1
                    counter += 1
                    if counter == 3:
                        print("Incorrect pin trials over please start over.")
                        break
                    pin = int(input("Enter your pin no = "))
                    continue
        else:
            print("No Record Found in Our Database. Please Try Again...!")

    def transferAmount(self):
        accNo = int(input("Enter your Account no = "))
        query = ("select Accountnumber from Account where Accountnumber > 0")
        cursor.execute(query)
        temp = cursor.fetchall()
        data_accNo = [i[0] for i in temp]
        counter = 0
        trails = 2
        if accNo in data_accNo:
            pin = int(input("Enter your pin no = "))
            query = (f"select Pin from Account where Accountnumber = {accNo}")
            cursor.execute(query)
            data_pin = cursor.fetchall()[0][0]
            while counter != 3:
                if data_pin == pin:
                    accNo2 = int(input("Enter Account no you wish to transfer = "))
                    query = ("select Accountnumber from Account where Accountnumber > 0")
                    cursor.execute(query)
                    temp2 = cursor.fetchall()
                    data_accNo2 = [i[0] for i in temp2]
                    if accNo2 in data_accNo2:
                        tBal = int(input("Enter amount to tranfer = "))
                        query = (f"select OpeningBalance from Account where Accountnumber = {accNo}")
                        cursor.execute(query)
                        accBal = cursor.fetchall()[0][0]
                        min_Bal = accBal-tBal
                        if min_Bal > accBal:
                            print("You Have insufficient Balance in your account please try again...")
                        else:
                            accBal -= tBal
                            print(f"Thanks for using our service. Remaining funds in your account = {accBal}")
                            query = (f"update Account set OpeningBalance = {accBal} where Accountnumber = {accNo}")
                            cursor.execute(query)
                            mydb.commit()
                            query = (f"select OpeningBalance from Account where Accountnumber = {accNo2}")
                            cursor.execute(query)
                            accBal2 = cursor.fetchall()[0][0]
                            accBal2 += tBal
                            query = (f"update Account set OpeningBalance = {accBal2} where Accountnumber = {accNo2}")
                            cursor.execute(query)
                            mydb.commit()
                            query = (f"select Name from Account where Accountnumber = {accNo}")
                            cursor.execute(query)
                            name = cursor.fetchall()[0][0]
                            query = (f"insert into amount (Name, Accountnumber, Balance, type, dot) "
                                 f"values ('{name}', {accNo}, {tBal} , 'Transfered' , '{dt.datetime.today()}' )")
                            cursor.execute(query)
                            mydb.commit()
                            query = (f"select Name from Account where Accountnumber = {accNo2}")
                            cursor.execute(query)
                            name = cursor.fetchall()[0][0]
                            query = (f"insert into amount (Name, Accountnumber, Balance, type, dot) "
                                     f"values ('{name}', {accNo2}, {tBal} , 'Recieved' , '{dt.datetime.today()}' )")
                            cursor.execute(query)
                            mydb.commit()
                        break
                else:
                    print("Incorrect Pin. Please Try again.")
                    if trails > 0:
                        print(f"You got {trails} more incorrect trials left.")
                    trails -= 1
                    counter += 1
                    if counter == 3:
                        print("Incorrect pin trials over please start over.")
                        break
                    pin = int(input("Enter your pin no = "))
                    continue
        else:
            print("No Record Found in Our Database. Please Try Again...!")

    def balanceEnq(self):
        accNo = int(input("Enter your Account no = "))
        query = ("select Accountnumber from Account where Accountnumber > 0")
        cursor.execute(query)
        temp = cursor.fetchall()
        data_accNo = [i[0] for i in temp]
        counter = 0
        trails = 2
        if accNo in data_accNo:
            pin = int(input("Enter your pin no = "))
            query = (f"select Pin from Account where Accountnumber = {accNo}")
            cursor.execute(query)
            data_pin = cursor.fetchall()[0][0]
            while counter != 3:
                if data_pin == pin:
                    query = (f"select OpeningBalance from Account where Accountnumber = {accNo}")
                    cursor.execute(query)
                    accBal = cursor.fetchall()[0][0]
                    print(f"Balance in your account = {accBal}")
                    print("Thanks for using our service")
                    break
                else:
                    print("Incorrect Pin. Please Try again.")
                    if trails > 0:
                        print(f"You got {trails} more incorrect trials left.")
                    trails -= 1
                    counter += 1
                    if counter == 3:
                        print("Incorrect pin trials over please start over.")
                        break
                    pin = int(input("Enter your pin no = "))
                    continue
        else:
            print("No Record Found in Our Database. Please Try Again...!")

t = Transaction()


