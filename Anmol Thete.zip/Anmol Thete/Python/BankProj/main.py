from admin import admins
from cutomer import customer
def main():
    while(1):
        print("Admin or Customer :- ")
        option = int(input("Enter 1 for admin and 2 for Customer : "))
        if(option== 1 ):
            admins()
        elif(option == 2):
            customer()
        else:
            print("Enter valid input ")
            main()

main()

