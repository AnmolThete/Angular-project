import datetime as dt
d = dt.datetime.today()
print(d.day)