import { ComponentFixture, fakeAsync, TestBed, tick, waitForAsync } from "@angular/core/testing";
import { Router } from "@angular/router";
import { RouterTestingModule } from "@angular/router/testing";
import { AppComponent } from "../app.component";
import { HomeComponent } from "../home/home.component";
import { ProductDetailComponent } from "./product-detail.component";
import { ProductComponent } from "./product.component";
/*let fixture: any;
let router:Router;
let location:Location;
beforeEach(waitForAsync(()=>{
    TestBed.configureTestingModule({
        imports: [RouterTestingModule.withRoutes(routes)],
        declarations :[
            AppComponent, ProductDetailComponent, HomeComponent
        ]
    }).compileComponents();
}));
beforeEach(fakeAsync(()=>{
    router = TestBed.inject(Router);
    location = TestBed.inject(Location);
    fixture = TestBed.createComponent(AppComponent);
    router.navigateByUrl('/');
    tick();
    fixture.detectChanges();
}));

/*it('can imagine and pass params to the product detail view', fakeAsync(()=>{
    const productLink = fixture.debugElement.query(By.css('#product'));
    productLink.triggerEventHandler('click',{button:0});
    tick();
    fixture.detectChanges();
    expect(location.path()).toEqual('product/1234');
}));
*/