import { Component } from '@angular/core';
import { ProductService } from '../product.service';
import { CartService } from './cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
 
})
export class CartComponent {

    

    constructor(
      private cartService: CartService,
    ) { }
    items = this.cartService.getItems();
    
    clearCart() {
      this.items = [];
      return this.items;
  }

    

}