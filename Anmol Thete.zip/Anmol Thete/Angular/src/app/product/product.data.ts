import {InMemoryDbService} from "angular-in-memory-web-api"
import { IProduct } from "./product.model";
export class ProductData implements InMemoryDbService{
    createDb(){
        const products:IProduct[]=[
            {"id":1,
            "name":"shirt",
            "category":"clothing brand",
            "price":999,
            "description":"Casuals shirt",
            "imageUrl":"assets/images/shirt.jpg",
            "rating":4.5,
        },
        {
            "id":2,
            "name":"football",
            "category":"sports",
            "price":1999,
            "description":"lightweight",
            "imageUrl":"assets/images/football.jpg",
            "rating":4,
        },
        {
            "id":3,
            "name":"shoes",
            "category":"loafers",
            "price":999,
            "description":"Casuals shoes",
            "imageUrl":"assets/images/shoes.jpg",
            "rating":3.5,
        },
        {
            "id":4,
            "name":"table",
            "category":"furniture",
            "price":4999,
            "description":"wooden",
            "imageUrl":"assets/images/table.jpg",
            "rating":5,
        },
        {
            "id":5,
            "name":"book",
            "category":"stationary",
            "price":399,
            "description":"fiction",
            "imageUrl":"assets/images/book.jpg",
            "rating":2.5,
        },
            
        
        ];
        return {products};
    }
}