import { HttpClient } from "@angular/common/http";
import { inject, TestBed, waitForAsync } from "@angular/core/testing";
import { ProductService } from './product.service';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import { Product } from "./product";
import { IProduct } from "./product.model";
describe('ProductService', ()=>{
    let productService=TestBed.inject(ProductService);
    let httpMock = TestBed.inject(HttpTestingController);


    beforeEach(()=> {
        TestBed.configureTestingModule({
        imports:[HttpClientTestingModule],
        providers:[ProductService]
            
            //providers:[{product:ProductService, useValue:mockProductService}]

        });

       
    })
  

  it('should  successfully get',waitForAsync(()=> {
     const productData:IProduct[]=[{
        "id":4,
        "name":"table",
        "category":"furniture",
        "price":4999,
        "description":"wooden",
        "imageUrl":"assets/images/table.jpg",
        "rating":5,
     }]
     productService.getProducts().subscribe(res=> expect(res).toEqual(productData))   
        let productsRequest = httpMock.expectOne('api/products');
        productsRequest.flush(productData);
  }))
    
  it('should successfully return error', waitForAsync(()=>{
    const errorType = "Cannot load products from the given url ";
    productService.getProducts().subscribe(()=>{},
    errorResponse => expect(errorResponse.error.type).toEqual(errorType));
    let productsRequest = httpMock.expectOne('api/products');
    productsRequest.error(new ErrorEvent(errorType));

    }));
    afterEach(()=>httpMock.verify());
})