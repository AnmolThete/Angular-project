import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Product } from "./product";
import { IProduct } from "./product.model";
import { ProductService } from "./product.service";
import { CartService } from './cart/cart.service';
import { FormGroup, FormControl, FormArray, FormBuilder } from '@angular/forms'  ;

@Component({
    selector: 'app-prod-detail',
    templateUrl:'./product-detail.component.html',

})
export class ProductDetailComponent implements OnInit{
    pageTitle:string="Product detail id ";
    message: string;
    product:Product;
    productForm: FormGroup;  
    constructor(private fb:FormBuilder,private route:ActivatedRoute, private router:Router,private productService: ProductService,  private cartService: CartService)
    {this.productForm = this.fb.group({  
       
      Tags: this.fb.array([]) ,  
    })  
  }
    addToCart(product: Product) {
      this.cartService.addToCart(product);
      window.alert('Your product has been added to the cart!');
    }
    ngOnInit(){
        
        let id= +this.route.snapshot.paramMap.get('id')
        this.pageTitle += ` :${id}`;
        this.productService.getProduct(id)
        .subscribe(
          products => {
            this.product = products;
            console.log(products);
          },
          error => {
            console.log(error);
          });

          
          
        
        
    }
    deleteProduct(): void {
      this.productService.deleteProduct(this.product.id)
        .subscribe(
          response => {
            console.log(response);
            this.router.navigate(['/product']);
          },
          error => {
            console.log(error);
          });
    }
    updateProduct(): void {
      this.productService.updateProduct( this.product)
        .subscribe(
          response => {
            console.log(response);
            this.message = 'The product was updated!';
          },
          error => {
            console.log(error);
          });
    }

    onBack():void{
        this.router.navigate(['/product'])
    }

   
    Tags() : FormArray {  
      return this.productForm.get("Tags") as FormArray  
    }  
       
    newTag(): FormGroup {  
      return this.fb.group({  
        tag: '',  
          
      })  
    }  
       
    addTag() {  
      this.Tags().push(this.newTag());  
    }  
       
    removeTag(i:number) {  
      this.Tags().removeAt(i);  
    }  
       
    

    
}


