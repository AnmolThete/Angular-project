import { Component, Directive, ElementRef, OnInit } from '@angular/core';
import { IProduct } from './product.model';
import { ProductService } from './product.service';
//import { ttClassDirective } from './product.directive';
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";


@Component({
  selector: 'app-product',
  templateUrl: './product.template.html',
  styleUrls: ['./product.component.css']
})

export class ProductComponent implements OnInit {
  errorMessage:string;
  color="bg-danger";
  condition = false;
  fontSizewithUnits:string="30px";
  fontSizewithoutUnits:string="40px";
  productList:IProduct[];
  listFilter:string='';
 
  

  constructor(private pdtService:ProductService,el: ElementRef){
    el.nativeElement.style.backgroundColor = 'yellow';
  }

  ngOnInit(): void {
    this.pdtService.getProducts().subscribe({
      next:products=>{
        this.productList=products;
      },
      error:err => this.errorMessage=err
    })
  }
  

  
  getProducts(){
  }

  
  ratingReview:string;
  onratingClicked(message:string):void{
    this.ratingReview = "Rating review "+ message
  }


}
