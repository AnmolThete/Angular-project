import { Component, OnInit } from "@angular/core";
import { NgForm } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { Product } from "../product";
import { ProductService } from "../product.service";


@Component({
    selector: 'app-prod-edit',
    templateUrl:'./product-edit.component.html',

})
export class ProductEditComponent implements OnInit{
    product:Product;
    formSubmitted:boolean=false;
    //newProduct = new Product();
    constructor(private route:ActivatedRoute, private router:Router, private pdtService:ProductService){}
    ngOnInit(){
        let id= +this.route.snapshot.paramMap.get('id')
        
        this.pdtService.getProduct(id)
        .subscribe(
          products => {
            this.product = products;
            console.log(products);
          },
          error => {
            console.log(error);
          });
    }

    updateProduct(values){
        this.pdtService.updateProduct(JSON.parse(JSON.stringify(this.product))).subscribe(result=>{
            this.router.navigate(['/product'])
        })
    }
  
    //formSubmitted:boolean=false;
    submitForm(form:NgForm){
        this.formSubmitted=true;
        if(form.valid){
            this.updateProduct(this.product);
            this.product=new Product();
            form.reset();
            this.formSubmitted=false;
        }
    }
       
    

    
}


