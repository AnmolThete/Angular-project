import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CartComponent } from './product/cart/cart.component';
import { ProductDetailComponent } from './product/product-detail.component';
import { ProductDetailGuard } from './product/product-detail.guard';
import { ProductEditComponent } from './product/product-edit/product-edit.component';
import { ProductFormComponent } from './product/product-form.component';
import { ProductComponent } from './product/product.component';

const routes: Routes = [
  {
    path:'Home',component:HomeComponent
  },
  {
    path:'product',component:ProductComponent
  },
  {
    path:'product/:id', canActivate:[ProductDetailGuard], component:ProductDetailComponent
  },
  
  {
    path:'addproduct', component:ProductFormComponent
  },
  {
    path:'productEdit/:id', component:ProductEditComponent
  },
  { path: 'cart', component: CartComponent },
  
  {path:'',redirectTo:'Home', pathMatch:'full'},
  {path:'**',redirectTo:'Home', pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
