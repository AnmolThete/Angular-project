import { Component, Input, OnChanges, OnInit, Output, SimpleChange } from '@angular/core';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-star',
  templateUrl: './star.component.html',
  
})
export class StarComponent implements OnChanges {
  @Input()
  rating:number;
  starWidth:number;
  @Output() ratingClicked:EventEmitter<string>=new EventEmitter<string>();
  ngOnChanges():void{
    this.starWidth=this.rating*(90/5);

  }

  onClick():void{
    this.ratingClicked.emit(`this rating is ${this.rating}`)
  }

 
}
