import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule } from '@angular/common/http';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ProductFormComponent } from './product/product-form.component';
import { ProductComponent } from './product/product.component';
import { ProductService } from './product/product.service';
import { ProductData } from './product/product.data';
import { StarComponent } from './star/star.component';
import { ProductDetailComponent } from './product/product-detail.component';
import { CartService } from './product/cart/cart.service';
import { CommonModule } from "@angular/common";
import { ProductEditComponent } from './product/product-edit/product-edit.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CartComponent } from './product/cart/cart.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ProductComponent,
    ProductFormComponent,
    StarComponent,
    ProductDetailComponent,
    ProductEditComponent,
    CartComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    CommonModule,
    InMemoryWebApiModule.forRoot(ProductData),
    NgbModule,

  ],
  providers: [ProductService, CartService],
  bootstrap: [AppComponent]
})
export class AppModule { }
